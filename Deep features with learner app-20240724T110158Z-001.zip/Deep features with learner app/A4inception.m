clear all;
clc;
close all;

imds = imageDatastore('E:\drMudassar\myCodebrats2015\DatasetFLAIR1', ...
    'IncludeSubfolders',true, ...
    'LabelSource','foldernames');

numTrainImages = numel(imds.Labels);

net=inceptionv3;
 
net.Layers
analyzeNetwork(net)

inputSize = net.Layers(1).InputSize;

augmentedTrainingSet = augmentedImageDatastore(inputSize(1:2),imds);

layer = 'avg_pool';
InceptionfeaturesTrain = activations(net,augmentedTrainingSet,layer,'OutputAs','rows');

YTrain = imds.Labels;

save('InceptionfeaturesTrain.mat','InceptionfeaturesTrain');


