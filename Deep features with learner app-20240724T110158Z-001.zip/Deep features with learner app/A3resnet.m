clear all;
clc;
close all;

imds = imageDatastore('E:\drMudassar\myCodebrats2015\DatasetFLAIR1', ...
    'IncludeSubfolders',true, ...
    'LabelSource','foldernames');

numTrainImages = numel(imds.Labels);

net = resnet50();

net.Layers
analyzeNetwork(net)

inputSize = net.Layers(1).InputSize;

augmentedTrainingSet = augmentedImageDatastore(inputSize(1:2),imds);

layer = 'avg_pool';
ResnetfeaturesTrain = activations(net,augmentedTrainingSet,layer,'OutputAs','rows');

YTrain = imds.Labels;
save('ResnetfeaturesTrain.mat','ResnetfeaturesTrain');


