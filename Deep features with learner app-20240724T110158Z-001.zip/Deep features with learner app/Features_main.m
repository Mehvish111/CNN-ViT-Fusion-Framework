clc; 
clear all;
 close all;
imagespath=imageSet('E:\drMudassar\myCodebrats2015\DatasetFLAIR1','recursive');%return size os sub-folders
imagecount=1;
s = size(imagespath,2);                        %size of image folder
for i=1 : size(imagespath,2)
    m=size(imagespath(i).ImageLocation,2);     %count number of images in each folder
    temp=imagespath(i).ImageLocation;           % find the addresses of the images locations
     for j=1 :  m
        v{imagecount,1}=temp{j};
            if(~isempty(strfind(temp{j},'HGG')))
                v{imagecount,2}='A';
            elseif (~isempty(strfind(temp{j},'LGG')))
                v{imagecount,2}='B';
            end           
            
            img=imread(v{imagecount,1});
            img=rgb2gray(img);
            img=otsu(img,3);        
             img=imresize(img,[128,64]);       
             
             featureVector2=extractHOGFeatures(img);
             feature2{imagecount,1}=featureVector2(1,:);
             imagecount=imagecount+1;
     end
end

for i=1:length(feature2)
    ftemp2=double(feature2{i});    
    FV2(i,:)=ftemp2;  
end
X=v(:,2);
%============================AlexNet Features ============
load('AlexfeaturesTrain.mat');
AlexfeaturesTrain=double(AlexfeaturesTrain);
load('InceptionfeaturesTrain.mat');
InceptionfeaturesTrain=double(InceptionfeaturesTrain);
 load('ResnetfeaturesTrain.mat');
 ResnetfeaturesTrain=double(ResnetfeaturesTrain);
load('vgg16featuresTrain.mat');
vgg16featuresTrain=double(vgg16featuresTrain);
%===================================================

[pc2,score1] =  princomp(FV2);

[pc4,score2] =  princomp(AlexfeaturesTrain);
 [pc5,score3] = princomp(InceptionfeaturesTrain);
[pc6,score4]=   princomp(ResnetfeaturesTrain);
[pc7,score5]=   princomp(vgg16featuresTrain);

    red_dim_HOG =      score1(:,1:59);    
    Alexfeatures=      score2(:,1:250);
    Inceptionfeatures= score3(:,1:250);
    Resnetfeatures=    score4(:,1:250);
    vgg16features=     score5(:,1:250);
    

  FusedFeatures = horzcat( Alexfeatures,Inceptionfeatures,Resnetfeatures,vgg16features,red_dim_LBP);
  FusedFeatures(:,size(FusedFeatures,2)+1)=cell2mat(X);

  FusedFeatures1 = horzcat(Inceptionfeatures,red_dim_LBP);
  FusedFeatures1(:,size(FusedFeatures1,2)+1)=cell2mat(X);
  
  FusedFeatures3 = horzcat(Resnetfeatures,vgg16features,red_dim_LBP);
  FusedFeatures3(:,size(FusedFeatures3,2)+1)=cell2mat(X);
