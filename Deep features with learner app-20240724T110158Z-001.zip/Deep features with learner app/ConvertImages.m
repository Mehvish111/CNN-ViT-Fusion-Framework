clc; 
clear all;
 close all;
imagespath=imageSet('E:\drMudassar\myCodebrats2015\DatasetT2','recursive');%return size os sub-folders
imagecount=1;
s = size(imagespath,2);                        %size of image folder
for i=1 : size(imagespath,2)
    m=size(imagespath(i).ImageLocation,2);     %count number of images in each folder
    temp=imagespath(i).ImageLocation;           % find the addresses of the images locations
    count1=1;
    count2=1;
     for j=1 :  m
        img=imread(temp{j});
        [r,c,channels]=size(img);
        
        if channels==1
            img1=cat(3,img,img,img);
        end
            path='DatasetT21';
            if(~isempty(strfind(temp{j},'HGG')))
                path=strcat(path,'\HGG\',num2str(count1),'.png');
                imwrite(img1,path);
                count1=count1+1;
             
            elseif (~isempty(strfind(temp{j},'LGG')))
                path=strcat(path,'\LGG\',num2str(count2),'.png');
                imwrite(img1,path);
                count2=count2+1;
            end

     end
end

